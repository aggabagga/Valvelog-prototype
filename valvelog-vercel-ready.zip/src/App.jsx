import React from 'react'

function App() {
  return (
    <div>
      <h1>Valve Log Prototype</h1>
      <p>This is a basic Vite + React setup ready for Vercel deployment.</p>
    </div>
  )
}

export default App