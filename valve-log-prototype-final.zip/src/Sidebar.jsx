import React from "react";

const data = {
  "Gullfaks A": {
    "XT-12": {
      "Slot 5": ["Valve A", "Valve B"],
      "Slot 6": ["Valve C"]
    },
    "XT-13": {
      "Slot 2": ["Valve D"]
    }
  }
};

const Sidebar = ({ onSelectValve }) => {
  return (
    <div style={{ width: "300px", background: "#f0f0f0", padding: "10px", overflowY: "auto" }}>
      <h3>Navigation</h3>
      <ul>
        {Object.entries(data).map(([field, templates]) => (
          <li key={field}>
            <strong>{field}</strong>
            <ul>
              {Object.entries(templates).map(([template, slots]) => (
                <li key={template}>
                  {template}
                  <ul>
                    {Object.entries(slots).map(([slot, valves]) => (
                      <li key={slot}>
                        {slot}
                        <ul>
                          {valves.map((valve) => (
                            <li key={valve}>
                              <button onClick={() => onSelectValve(valve)}>{valve}</button>
                            </li>
                          ))}
                        </ul>
                      </li>
                    ))}
                  </ul>
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Sidebar;
