import React, { useState } from "react";
import Sidebar from "./Sidebar";
import ValveLog from "./ValveLog";

const App = () => {
  const [selectedValve, setSelectedValve] = useState(null);

  return (
    <div style={{ display: "flex", height: "100vh", fontFamily: "Arial" }}>
      <Sidebar onSelectValve={setSelectedValve} />
      <div style={{ flex: 1, padding: "20px" }}>
        <h1>Valve Operation Log</h1>
        {selectedValve ? (
          <ValveLog valve={selectedValve} />
        ) : (
          <p>Select a valve from the menu to begin.</p>
        )}
      </div>
    </div>
  );
};

export default App;
