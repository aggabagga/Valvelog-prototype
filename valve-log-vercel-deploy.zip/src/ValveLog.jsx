import React, { useState } from "react";

const ValveLog = ({ valve }) => {
  const [form, setForm] = useState({
    operation: "open",
    breakOut: "",
    running: "",
    makeUp: "",
    turns: ""
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Submitted operation for " + valve + ":\n" + JSON.stringify(form, null, 2));
  };

  return (
    <div>
      <h2>Valve: {valve}</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Operation:</label>
          <select name="operation" value={form.operation} onChange={handleChange}>
            <option value="open">Open</option>
            <option value="close">Close</option>
          </select>
        </div>
        <div>
          <label>Break-out torque:</label>
          <input name="breakOut" value={form.breakOut} onChange={handleChange} />
        </div>
        <div>
          <label>Running torque:</label>
          <input name="running" value={form.running} onChange={handleChange} />
        </div>
        <div>
          <label>Make-up torque:</label>
          <input name="makeUp" value={form.makeUp} onChange={handleChange} />
        </div>
        <div>
          <label>Number of turns:</label>
          <input name="turns" value={form.turns} onChange={handleChange} />
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default ValveLog;
